package com.dantes.demo.entities;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.stereotype.Component;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.OrderColumn;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

// mandatory annotation 

@Component
@Entity
@Table(name = "vendor_data")

public class Vendor {

	@Id
	@Column(nullable = false, name = "id")
//	@GeneratedValue(strategy = GenerationType.AUTO)
	@GenericGenerator(name = "uuid2", strategy = "uuid2")
	@GeneratedValue(strategy = GenerationType.IDENTITY, generator = "uuid2")
	private String Code;

	public String getCode() {
		return Code;
	}

	public void setCode(String code) {
		Code = code;
	}

//	private String CompanyName;

	public String getCompanyName() {
		return CompanyName;
	}

	public void setCompanyName(String companyName) {
		CompanyName = companyName;
	}

//	private String ContactPerson;

	public String getContactPerson() {
		return ContactPerson;
	}

	public void setContactPerson(String contactPerson) {
		ContactPerson = contactPerson;
	}

//	private String FirstName;

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

//	private String LastName;

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

//	private String Website;

	public String getWebsite() {
		return Website;
	}

	public void setWebsite(String website) {
		Website = website;
	}

//	private String email;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

//	private String status;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

//	private Date RegDate;

	public Date getRegDate() {
//	public Timestamp getRegDate() {	
		return RegDate;
	}

	public void setRegDate(Date regDate) {
//	public void setRegDate(Timestamp regDate) {	
		RegDate = regDate;
	}

	@Column(nullable = false, name = "company_name")
	private String CompanyName;

	@Column(nullable = false, name = "cotact_person")
	private String ContactPerson;

	@Column(nullable = false, name = "first_name")
	private String FirstName;

	@Column(nullable = true, name = "last_name")
	private String LastName;

	@Column(nullable = true, name = "website")
	private String Website;

	@Column(nullable = true, name = "email")
	private String email;

	@Column(nullable = false, name = "status")
	private String status;

	@Column(nullable = true, name = "reg_date")
	private Date RegDate;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "vendor_id", referencedColumnName = "id")
	private List<Address> addresses = new ArrayList<>();

	public List<Address> getAddresses() {
		return addresses;
	}

	public void setAddresses(List<Address> addresses) {
		this.addresses = addresses;
	}

	// private String Code;
	// private String CompanyName;
	// private String ContactPerson;
	// private String FirstName;
	// private String LastName;
	// private String Website;
	// private String email;
	// private String status;
	// private Date RegDate;

//	public Vendor(String code, String companyName, String contactPerson, String firstName, String lastName,
//			String website, String email, String status, Date regDate) {

	public Vendor() {
		super();

// In the following Order the output items will be displayed BUT IT DIDNT 
//		this.Code = "Vendor_1";
//		this.CompanyName = "Nephra Proxim";
//		this.ContactPerson = "Alec";
//		this.FirstName = "Jaques";
//		this.LastName = "Lexine";
//		this.Website = "www.google.com";
//		this.email = "arya_stark@nep.com";
//		this.status = "A";
//		this.RegDate = new Date(0);
//		this.RegDate = new Timestamp(0);

//		email = "arya_stark@nep.com";
//		status = "A";
//		Code = "Vendor_1";
//		CompanyName = "Nephra Proxim";
//		ContactPerson = "Alec";
//		FirstName = "Jaques";
//		LastName = "Lexine";
//		Website = "www.google.com";
//		RegDate = new Date(0);		
	}

	public Vendor(String code, String companyName, String contactPerson, String firstName, String lastName,
			String website, String email, String status, Date regDate) {
		super();
		Code = code;
		CompanyName = companyName;
		ContactPerson = contactPerson;
		FirstName = firstName;
		LastName = lastName;
		Website = website;
		this.email = email;
		this.status = status;
		RegDate = regDate;
	}

	@Override
	public String toString() {
		return "Vendor" + "[Code=" + Code + ", " + "CompanyName=" + CompanyName + ", " + "ContactPerson="
				+ ContactPerson + "," + "FirstName=" + FirstName + ", " + "LastName=" + LastName + ", " + "Website="
				+ Website + ", " + "email=" + email + "," + "status=" + status + ", " + "RegDate=" + RegDate + "]";
	}

}
