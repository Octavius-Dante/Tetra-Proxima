package com.dantes.demo.service;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dantes.demo.entities.Address;

public interface IAddressPersistance extends JpaRepository<Address, String> {

}
