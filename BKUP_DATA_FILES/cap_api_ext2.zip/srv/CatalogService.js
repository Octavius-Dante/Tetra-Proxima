const cds = require("@sap/cds");

module.exports = cds.service.impl(async function(srv){

    const { MySalesOrder } = this.entities;
    const { opApiSalesOrderSrv0001 } = require('./sales-order-api/OP_API_SALES_ORDER_SRV_0001');

   var getAllSalesOrders = async function(){

    // const { opApiSalesOrderSrv0001 } = require('./sales-order-api/OP_API_SALES_ORDER_SRV_0001');
    const { SalesOrderApi } = opApiSalesOrderSrv0001();

    const dataSalesData = await SalesOrderApi.requestBuilder().getAll().top(5)
        .select(
            salesOrderApi.schema.SALES_ORDER,
            salesOrderApi.schema.SALES_ORDER_TYPE,
            salesOrderApi.schema.SALES_ORGANIZATION,
            salesOrderApi.schema.SOLD_TO_PARTY,
            salesOrderApi.schema.PAYMENT_METHOD,
            salesOrderApi.schema.TO_ITEM
        )
    .execute({
        // For BTP deployment prod
        //destinationName: "S4HANA"  

        // for local testing 
        // "url": "123.456.789.123:9999",
        // "username": "Tesla",
        // "password": "Amazing@111"        
        "url": "122.162.240.164:8021",
        "username": "mob55",
        "password": "user@550"
    });
    return dataSalesData;

   };

 // Read record for this salesorderset srv declared in CatalogService.cds
srv.on('READ', MySalesOrder, async (request) => {
        return await getAllSalesOrders().then(
            salesOrderTable => {
                var aRecord = [];

// what data we are getting from system we can print it here to diagnose the issues                
                console.log(salesOrderTable);
                salesOrderTable.forEach(element => {
                    
                    var item = {};
                    item.SalesOrder = element.salesOrder;
                    item.SalesOrganization = element.salesOrganization;
                    item.SalesOrderType = element.salesOrderType;
                    item.SalesOrderDate = element.salesOrderDate;
                    item.SoldToParty = element.soldToParty;
                    item.OverallDeliveryStatus = element.overallDeliveryStatus;

// if item table contain values assign it                    
                    if(element.toItem[0]){
                        item.Material = element.toItem[0].material;
                        item.OrderQuantityUnit = element.toItem[0].orderQuantityUnit;
                        item.RequestedQuantity = element.toItem[0].requestedQuantity;
                        item.NetAmount = element.toItem[0].netAmount;
// if item table doesnt contain values show empty
                    }else{
                        item.Material = "";
                        item.OrderQuantityUnit = "";
                        item.RequestedQuantity = "";
                        item.NetAmount = "";
                    }
                    aRecord.push(item);
                });
                return aRecord;
            }
        );
    });
});