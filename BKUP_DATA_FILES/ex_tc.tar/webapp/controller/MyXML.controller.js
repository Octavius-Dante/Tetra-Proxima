sap.ui.define([
    'sap/ui/core/mvc/Controller',
    'chip/model/models'
], function(Controller, Models) {
    'use strict';
    return Controller.extend("chip.controller.MyXML",{
        onInit: function(){
            this.oView = this.getView();
            //Calling our own reuse class to create model object
            var oModel = Models.createJSONModel("model/mockdata/sample.json");
            //oModel.setDefaultBindingMode("OneWay");
            //Step 3: Make the model aware to the application
            sap.ui.getCore().setModel(oModel); //a model with no name is default model
            //this.getView().setModel(oModel);
            
            //---Example create 2nd model - json type
            var oModel2 = Models.createJSONModel("model/mockdata/dataset.json");
            //named model - we need to give a name
            sap.ui.getCore().setModel(oModel2, "got");

            //var oXmlModel = Models.createXMLModel("model/mockdata/mydemo.xml");
            //sap.ui.getCore().setModel(oXmlModel);

            //Step 4 : Binding syntax 3-4
            var oSalary = this.getView().byId("idEmpSal");
            oSalary.bindValue('/empStr/salary');
            var oCurr = this.getView().byId("idCurr");
            oCurr.bindProperty("value", "/empStr/currency");

        },
        //Ctrl+Slash /
        onBtnClick: function(){
                debugger;
                //var oInp = sap.ui.getCore().byId("idText");  //this.getView().byId("idText")
                var oInp = this.oView.byId("idText");
                alert(oInp.getValue());
            },
        //oView: this.getView(),
        name: "Ananya",
        onFlip: function(){
            var oModel = sap.ui.getCore().getModel();
            var oGOTModel = sap.ui.getCore().getModel("got");
            sap.ui.getCore().setModel(oGOTModel);
            sap.ui.getCore().setModel(oModel, "got");
        },
        onReload: function(){
            
            //Step 1: Get The Model OBject
            var oModel = sap.ui.getCore().getModel();
            //Step 2: Change Data in the Model
            var oData = oModel.getProperty("/empStr");
            console.log(oData);
            oModel.setProperty("/empStr/empName", "Spiderman");

            //Get the view object, from that get Control Object
            //Set the value becuase there is a value property
            // this.oView.byId("idEmpId").setValue("100");
            // this.oView.byId("idEmpName").setValue(this.name);
            // this.oView.byId("idEmpSal").setValue("9500");
            // this.oView.byId("idCurr").setValue("USD");
        },
        onShowMe: function(){
            //Step 1: Get The Model OBject
            var oModel = sap.ui.getCore().getModel();
            //Step 2: Change Data in the Model
            var oData = oModel.getProperty("/");
            console.log(oData);
        }
    });
});
