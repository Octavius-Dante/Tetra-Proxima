var reuse = require('./util/02reuse');

reuse.addNumbers(50,22);
reuse.printJSON({"team": "Manchester", "player": "Chistiano Ronaldo"});
reuse.printArray([75,99,35,45,25]);
