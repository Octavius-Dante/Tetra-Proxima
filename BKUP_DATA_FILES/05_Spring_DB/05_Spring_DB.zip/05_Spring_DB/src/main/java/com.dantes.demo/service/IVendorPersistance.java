package com.dantes.demo.service;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dantes.demo.entities.Vendor;

public interface IVendorPersistance extends JpaRepository<Vendor, String> {

// didnt work	
//	List <Vendor> findByCompanyName(String companyName);

//	didnt work
//	@Query(nativeQuery = true, value = "SELECT * FROM public.vendor_data where company_name = ?1")
//	List<Vendor> findByCompanyName(String companyName);

	
// This following Query Works 	
	@Query(nativeQuery = true, value = "SELECT * FROM public.vendor_data where lower(first_name) like %?1% ")
	List<Vendor> lookupByFirstName(String firstName);
}
