const cds = require("@sap/cds");

module.exports = cds.service.impl(async function(){
  const { Customers } = this.entities;
  const service = await cds.connect.to("NorthWind");
  this.on('READ', Customers, async (request) => {    
    // check, pre-checks, make filters, authorization, security
    var data = await service.tx(request).run(request.query);
    console.log(data);  // <------ This part works       
    data.push({   // <------ This part works after installing  @sap/cds-dk , @sap/cds 
        "CustomerID": "CLEON",
        "CompanyName": "Dante explore",
        "ContactName": "cassian andor",
        "ContactTitle": "Developer",
        "Address": "KCD street",
        "City": "Kuttenberg",
        "Region": null,
        "PostalCode": "12209",
        "Country": "Hungary",
        "Phone": "030-0074321",
        "Fax": "030-0076545"
    });    
    return data// <------ This part works after installing  @sap/cds-dk , @sap/cds 
  });
});
