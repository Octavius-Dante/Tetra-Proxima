sap.ui.require(
    [
        'sap/fe/test/JourneyRunner',
        'com/dante/purchaseorderapp/test/integration/FirstJourney',
		'com/dante/purchaseorderapp/test/integration/pages/POsList',
		'com/dante/purchaseorderapp/test/integration/pages/POsObjectPage',
		'com/dante/purchaseorderapp/test/integration/pages/PurchseOrderItemsObjectPage'
    ],
    function(JourneyRunner, opaJourney, POsList, POsObjectPage, PurchseOrderItemsObjectPage) {
        'use strict';
        var JourneyRunner = new JourneyRunner({
            // start index.html in web folder
            launchUrl: sap.ui.require.toUrl('com/dante/purchaseorderapp') + '/index.html'
        });

       
        JourneyRunner.run(
            {
                pages: { 
					onThePOsList: POsList,
					onThePOsObjectPage: POsObjectPage,
					onThePurchseOrderItemsObjectPage: PurchseOrderItemsObjectPage
                }
            },
            opaJourney.run
        );
    }
);